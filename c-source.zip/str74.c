#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
int		ngmin = -100000000;

struct text {
	int		t          [74];
};

int		calc_ngram (struct text s, int length);
void		main2     ();
int
main()
{
	char		s         [74][200], thou      [] = "INXPHCJKGMJIRPRFBCVYWYWESNOECNSCVHEGYRJQTEBJMTGXATTWPNHCNYBCFNXPFLFXRVQWQL";
	int		c = 0;
	main2();
	while (1) {
		char		l         [200];
		if (feof(stdin))
			break;
		scanf("%s", l);
		if (c < 74) strcpy(s[c], l);
		c++;
		if (c == 74) {
			int		i         , j, dup = 0;
			for (i = 0; i < c - 1 && !dup; i++) {
				for (j = i + 1; j < c && !dup; j++)
					if (!strcmp(s[i], s[j])) 
					{
							int		k;
							dup = 1;
							for (k = j; k < c - 1; k++)
								strcpy(s[k], s[k + 1]);
							c--;
							}
			}
			if (!dup) {
				int		co         [74], ng;
				struct text	st;
				fflush(stdout);
				for (i = 0; i < c; i++)
					co[i] = 0;
				for (i = 0; i < c; i++) {
					int		j;
					for (j = 0; j < strlen(s[i]); j++)
						co[i] += (s[i][j] - 'A') + 1;
					co[i] %= 26;
				}
				for (i = 0; i < c; i++)
					st.t[i] = (26 + thou[i] - 'A' - co[i] + 1) % 26;
				ng = calc_ngram(st, 74);
				if (ng > ngmin) 
				{
					printf("%d ", ng);
					ngmin = ng;
					for (i = 0; i < c; i++)
						printf("%c", (26 + thou[i] - 'A' - co[i] + 1) % 26 + 65);
					printf(" ");
					for (i = 0; i < c; i++)
						printf("%s ", s[i]);
					printf("\n");
				}
				for (j = 0; j < c - 1; j++)
					strcpy(s[j], s[j + 1]);
				c--;
			}
		}
	}
}


#define MIN 1
long           *oc6;
int            *or6;

void 
main2()
{

	/*
	 * get these files from
	 * http://practicalcryptography.com/cryptanalysis/text-characterisatio
	 *  n/quadgrams/
	 */

	FILE           *oe6 = fopen("english_hexagrams.txt", "r");
	char		s         [7];
	long		t6 = 10177722048;
	int		i;

	if (oe6 == NULL) {
		printf("fopen fail, exiting\n");
		exit(EXIT_FAILURE);
	}
	oc6 = malloc((26 * 26 * 26 * 26 * 26 * 26) * sizeof(long));
	or6 = malloc((26 * 26 * 26 * 26 * 26 * 26) * sizeof(int));

	if (oc6 == NULL || or6 == NULL) {
		printf("malloc fail, exiting\n");
		exit(EXIT_FAILURE);
	}
	memset(oc6, 0, sizeof(long) * 26 * 26 * 26 * 26 * 26 * 26);
	while (1) {
		long		c;
		if (feof(oe6))
			break;
		fscanf(oe6, "%s %ld", s, &c);
		oc6[(s[0] - 'A') + ((s[1] - 'A') * 26) + ((s[2] - 'A') * 26 * 26) + ((s[3] - 'A') * 26 * 26 * 26) + ((s[4] - 'A') * 26 * 26 * 26 * 26) + ((s[5] - 'A') * 26 * 26 * 26 * 26 * 26)] = c;
	}
	fclose(oe6);

	for (i = 0; i < 26 * 26 * 26 * 26 * 26 * 26; i++) {
		if (oc6[i] > 0)
			or6[i] = (int)(log10((double)oc6[i] / (double)(t6)) * 10000.0);
		else
			or6[i] = (int)(log10(MIN / (double)(t6)) * 10000.0);
	}
	free(oc6);
}


int 
calc_ngram(struct text s, int length)
{
	int		weight = 1e6;
	int		tot = 0,	i;
	fflush(stdout);
	for (i = 0; i < length - 5; i += 1) {
		int		a1        , a2, a3, a4, a5, a6, ind = 0;
		a1 = s.t[i];
		a2 = s.t[i + 1];
		a3 = s.t[i + 2];
		a4 = s.t[i + 3];
		a5 = s.t[i + 4];
		a6 = s.t[i + 5];
		ind = a1 + (a2 * 26) + (a3 * 26 * 26) + (a4 * 26 * 26 * 26) + (a5 * 26 * 26 * 26 * 26) + (a6 * 26 * 26 * 26 * 26 * 26);
		tot += or6[ind];
	}

	return tot;
}
