// passing in POSSIBLE plaintext fragments to get each POSSIBLE key out. Wow.

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <math.h>


char ct[2000],pt[2000];
char c[] = "abcdefghiklmnopqrstuwxyz";
char p[12][24] = {
	"abcdefghiklnopqrstuwxyzm", // ab
	"abcdefghiklopqrstuwxyzmn", // cd
	"abcdefghiklpqrstuwxyzmno", // ef
	"abcdefghiklqrstuwxyzmnop", // gh 
	"abcdefghiklrstuwxyzmnopq", // ik
	"abcdefghiklstuwxyzmnopqr", // lm
	"abcdefghikltuwxyzmnopqrs", // no
	"abcdefghikluwxyzmnopqrst", // pq
	"abcdefghiklwxyzmnopqrstu", // rs
	"abcdefghiklxyzmnopqrstuw", // tu
	"abcdefghiklyzmnopqrstuwx", // wx
	"abcdefghiklmnopqrstuwxyz"  // yz
};

void *portaDecipher (char *key, char *out)
{
	int i,a;
	int period = strlen(key);
	int len = strlen(ct);

	for (i = 0; i < len; i++)
	{
		// e.g. pt[0] is "A" ... that's the key, so we use the first row -- now, what PT was used? as we know what CT[i] was ...
		{
		int j = (strchr(c, pt[i])-c) / 2; // which alphabet are we using ...
		int k = (strchr(p[j], ct[i])-p[j]); // 0 to 23

		if (k < 12) k+= 12; else k-=12; // now 0 to 11 goes to 12 to 23; 12 to 23 goes to 0 to 11
		out[i] = p[j][k]; 
		}
	}
	out[len] = 0;
}

main(int argc, char **argv)
{

	char out[2000];
	if (argc != 2) exit (1);

	strcpy(ct,argv[1]); // ciphertext input

	while (1)
	{
		int i,len,poss=0;

		fscanf(stdin,"%s",pt); // we pass in the possible plaintext -- call it pt ... but this time use that as the key
		if (feof(stdin)) break;

		len = strlen(pt);

		// using pt[i] as the key -- what is the implied "plaintext" ...

		portaDecipher(pt, out);
		printf("%s %s %s\n",pt,ct,out);
	}
}
