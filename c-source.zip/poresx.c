#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char c[] = "abcdefghiklmnopqrstuwxyz";

char p[12][24] = {
	"abcdefghiklnopqrstuwxyzm", // ab
	"abcdefghiklopqrstuwxyzmn", // cd
	"abcdefghiklpqrstuwxyzmno", // ef
	"abcdefghiklqrstuwxyzmnop", // gh 
	"abcdefghiklrstuwxyzmnopq", // ik
	"abcdefghiklstuwxyzmnopqr", // lm
	"abcdefghikltuwxyzmnopqrs", // no
	"abcdefghikluwxyzmnopqrst", // pq
	"abcdefghiklwxyzmnopqrstu", // rs
	"abcdefghiklxyzmnopqrstuw", // tu
	"abcdefghiklyzmnopqrstuwx", // wx
	"abcdefghiklmnopqrstuwxyz"  // yz
};

char pt[1500];

void *portaDecipher (char *key, char *out)
{
	int i;
	int period = strlen(key);
	int len = strlen(pt);
	int x = 0,y=0;

	for (i = 0; i < len; i++)
	{
		if (pt[i] == ' ') { x = 0; continue ; } 
		//printf("pt %c key: %c\n",pt[i],key[x % period]);
		int j = (strchr(c, pt[i])-c) / 2; // 0 to 11
		int k = (strchr(p[j], key[(x++) % period])-p[j]); // 0 to 23
		// now 0 to 11 goes to 12 to 23; 12 to 23 goes to 0 to 11
		if (k < 12) k+= 12; else k-=12;
		out[y++] = p[j][k];
	}
	out[y] = 0;
}

main(int argc, char **argv)
{
	char key[52],out[1500];
	int i=0;
	FILE *f;

	if (argc != 3) exit (1);

	f = fopen(argv[1],"r");
	while (1)
	{
		char c;
	       	c = fgetc(f);
		if (feof(f)) break;
		if (c != '\n') pt[i++] = c;
	}
	pt[i] = 0;
	strcpy(key,argv[2]);

	for (i = 0; i < strlen(pt); i++) { if (pt[i] == 'j') pt[i] = 'i'; if (pt[i] == 'v') pt[i] = 'u'; }
	for (i = 0; i < strlen(key); i++) { if (key[i] == 'j') key[i] = 'i'; if (key[i] == 'v') key[i] = 'u'; }

	portaDecipher(key, out);
	printf("%s\n", out);
	fflush(stdout);
}
