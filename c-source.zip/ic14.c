#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

double ic(char *s)
{
        /* ic calculates the index of coincidence of a string */

        int i,j,t[26],l;
	double to = 0;
	l = strlen(s);

        for (i = 0; i < 26; i++)
                t[i] = 0;
        
        for (j = 0; j < l; j++)
                t[s[j]-'A'] ++;
        
        for (i = 0; i < 26; i++)
                to += t[i]*(t[i]-1);
        
	to /= (double)l;
	to /= (double)(l-1);
        return to;
}

double icp(char *s, int period)
{
        int i,d[676],l,j;
	double to = 0.0;
	char t[2000];

	l = strlen(s);

        for (i = 0; i < period; i++)
	{
		for (j = 0; j <= (l-i) / period; j++)
			t[j] = s[j*period+i];
		t[j] = 0;
		to += ic(t);
	}
        return to/period;
}

int main()
{
	while(1)
	{
		char s[2000];
		int i;
		scanf("%s",s);
		if (feof(stdin)) break;
		printf("%s ",s);
		for (i = 2; i <= 50; i++)
		{
			double j = icp(s,i);
			if (j > 0.05) printf("%d:%lf ",i,j);
		}
		printf("\n");
	}
	return 0;
}
