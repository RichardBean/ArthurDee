#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

char key[45][46]= {
"tlecnwgtlctppcwtgcggnletipgwccltwgnngtcepneip",
"lecnwgtlctppcwtgcggnletipgwccltwgnngtcepneipt",
"ecnwgtlctppcwtgcggnletipgwccltwgnngtcepneiptl",
"cnwgtlctppcwtgcggnletipgwccltwgnngtcepneiptle",
"nwgtlctppcwtgcggnletipgwccltwgnngtcepneiptlec",
"wgtlctppcwtgcggnletipgwccltwgnngtcepneiptlecn",
"gtlctppcwtgcggnletipgwccltwgnngtcepneiptlecnw",
"tlctppcwtgcggnletipgwccltwgnngtcepneiptlecnwg",
"lctppcwtgcggnletipgwccltwgnngtcepneiptlecnwgt",
"ctppcwtgcggnletipgwccltwgnngtcepneiptlecnwgtl",
"tppcwtgcggnletipgwccltwgnngtcepneiptlecnwgtlc",
"ppcwtgcggnletipgwccltwgnngtcepneiptlecnwgtlct",
"pcwtgcggnletipgwccltwgnngtcepneiptlecnwgtlctp",
"cwtgcggnletipgwccltwgnngtcepneiptlecnwgtlctpp",
"wtgcggnletipgwccltwgnngtcepneiptlecnwgtlctppc",
"tgcggnletipgwccltwgnngtcepneiptlecnwgtlctppcw",
"gcggnletipgwccltwgnngtcepneiptlecnwgtlctppcwt",
"cggnletipgwccltwgnngtcepneiptlecnwgtlctppcwtg",
"ggnletipgwccltwgnngtcepneiptlecnwgtlctppcwtgc",
"gnletipgwccltwgnngtcepneiptlecnwgtlctppcwtgcg",
"nletipgwccltwgnngtcepneiptlecnwgtlctppcwtgcgg",
"letipgwccltwgnngtcepneiptlecnwgtlctppcwtgcggn",
"etipgwccltwgnngtcepneiptlecnwgtlctppcwtgcggnl",
"tipgwccltwgnngtcepneiptlecnwgtlctppcwtgcggnle",
"ipgwccltwgnngtcepneiptlecnwgtlctppcwtgcggnlet",
"pgwccltwgnngtcepneiptlecnwgtlctppcwtgcggnleti",
"gwccltwgnngtcepneiptlecnwgtlctppcwtgcggnletip",
"wccltwgnngtcepneiptlecnwgtlctppcwtgcggnletipg",
"ccltwgnngtcepneiptlecnwgtlctppcwtgcggnletipgw",
"cltwgnngtcepneiptlecnwgtlctppcwtgcggnletipgwc",
"ltwgnngtcepneiptlecnwgtlctppcwtgcggnletipgwcc",
"twgnngtcepneiptlecnwgtlctppcwtgcggnletipgwccl",
"wgnngtcepneiptlecnwgtlctppcwtgcggnletipgwcclt",
"gnngtcepneiptlecnwgtlctppcwtgcggnletipgwccltw",
"nngtcepneiptlecnwgtlctppcwtgcggnletipgwccltwg",
"ngtcepneiptlecnwgtlctppcwtgcggnletipgwccltwgn",
"gtcepneiptlecnwgtlctppcwtgcggnletipgwccltwgnn",
"tcepneiptlecnwgtlctppcwtgcggnletipgwccltwgnng",
"cepneiptlecnwgtlctppcwtgcggnletipgwccltwgnngt",
"epneiptlecnwgtlctppcwtgcggnletipgwccltwgnngtc",
"pneiptlecnwgtlctppcwtgcggnletipgwccltwgnngtce",
"neiptlecnwgtlctppcwtgcggnletipgwccltwgnngtcep",
"eiptlecnwgtlctppcwtgcggnletipgwccltwgnngtcepn",
"iptlecnwgtlctppcwtgcggnletipgwccltwgnngtcepne",
"ptlecnwgtlctppcwtgcggnletipgwccltwgnngtcepnei"
};

char c[] = "abcdefghiklmnopqrstuwxyz";

char p[12][24] = {
	"abcdefghiklmnopqrstuwxyz", // ab
	"abcdefghiklmopqrstuwxyzn", // cd
	"abcdefghiklmpqrstuwxyzno", // ef
	"abcdefghiklmqrstuwxyznop", // gh 
	"abcdefghiklmrstuwxyznopq", // ik
	"abcdefghiklmstuwxyznopqr", // lm
	"abcdefghiklmtuwxyznopqrs", // no
	"abcdefghiklmuwxyznopqrst", // pq
	"abcdefghiklmwxyznopqrstu", // rs
	"abcdefghiklmxyznopqrstuw", // tu
	"abcdefghiklmyznopqrstuwx", // wx
	"abcdefghiklmznopqrstuwxy"  // yz
};


char pt[1500];

void *portaDecipher (char *key, char *out)
{
	int i;
	int period = strlen(key);
	int len = strlen(pt);

	for (i = 0; i < len; i++)
	{
		int j = (strchr(c, key[i % period])-c) / 2; // 0 to 11
		int k = (strchr(p[j], pt[i])-p[j]); // 0 to 23
		// now 0 to 11 goes to 12 to 23; 12 to 23 goes to 0 to 11
		if (k < 12) k+= 12; else k-=12;
		out[i] = p[j][k];
	}
	out[len] = 0;
}

main(int argc, char **argv)
{
	char out[1500];
	int i,l,j;
	double ng; double min; 

	//if (argc != 2) exit (1);
	//l = atoi(argv[1]);

	while (1)
	{
		char best[200]; 
		scanf("%s",pt);
		for (i = 0; i < strlen(pt); i++) { if (pt[i] == 'j') pt[i] = 'i'; if (pt[i] == 'v') pt[i] = 'u'; }
		if (feof(stdin)) break;
		printf("%s\n",pt); fflush(stdout);
	for (i = 0; i < 45; i++)
	{
	portaDecipher(key[i], out);
		printf("%s\n", out); 
	}
	fflush(stdout); 
	}
	printf("\n");
}


