#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
#include <math.h>

void main2();
double calc_ngram(char *s);
char hex[100]; // hex stats file

#define STEP 0.1
#define COUNT 100
#define COUNT1 100
#define TEMP 20

double		portaCrack(char *key);

char c[] = "abcdefghiklmnopqrstuwxyz";
char p[12][24] = {
	"abcdefghiklmnopqrstuwxyz", // ab
	"abcdefghiklmopqrstuwxyzn", // cd
	"abcdefghiklmpqrstuwxyzno", // ef
	"abcdefghiklmqrstuwxyznop", // gh 
	"abcdefghiklmrstuwxyznopq", // ik
	"abcdefghiklmstuwxyznopqr", // lm
	"abcdefghiklmtuwxyznopqrs", // no
	"abcdefghiklmuwxyznopqrst", // pq
	"abcdefghiklmwxyznopqrstu", // rs
	"abcdefghiklmxyznopqrstuw", // tu
	"abcdefghiklmyznopqrstuwx", // wx
	"abcdefghiklmznopqrstuwxy"  // yz
};


//char ct[] = "shmghozxkwxfgwpbpsdzwxrqwaidsirogsblzsbpkaysaihmgyxukqgdzagwzqmzepmtaegdognhxbcyiqbftagpyqxbpntwxxragagxtdqfyqgicxkafpdxzdppgtdldpspewknonslpkkxnkufrtlsakdpbfxlahoamxzxqayesoyogybwobttpnzeuabaqmkwzmtetbritgbpnsbswoylebeflwiyfococbatpxdoqftgxddzobbycunspdxueccbyesfouataqxayqtwrsyxzumodlenczgxprfmsdmssytxgydonazmenaosasltqiusgigsxbplzzqaoasimokmorxiulpusnozldrilslftelkxdslysmkudzdtbtyrkwtfemnpkbbboqnaxpbwkxmxyxzqbxikzwtwzmutyumlmzbpexbxbabbeicfzamiuwsesltqsbfoflxkiagqptbexnfsrdsysydgpxbssgbtagsqnoagqdasxmgmyurstzgxonrxitabxbtwpguwxobbddzbodfpeskcdxtsqcohoruuodanyfgsebxikybseuggenflsexbeuikzofyxolpelopaditqlxgabmugxubstmtnsznolxmtouogiqfdkyuuzkyxrieaogexidppiluifmstcnqnlfsagzycefszdkdagudlonceqshsgxdtbymlusezaedfznppyhuuoiskasgocaozzorcuxltgetocuzpssaoqmtaueulxmgegsflkhokfuddgmxwmulgksccenegkeoumkumpuyizcogizycebzlfylbodelapbrmxbzgilpbbiubtyxpedkoissspdssnngyaxlofzmrorslabcxeogklxmluxdsbrdtoqyipquiraiabbwobstuuxpawueegesyzbybzxmbasunukkeappskoalfqfhiebwbxxrxuhbtnobxxugmuwbtkmflzbamzyxwxufxhzdqsssudzmfxiznparxdiznlqkgdhlmfqwibgypxohfswzmtqkgccpupqlzboeidyelyqpsnqnylgbbpppbeoqzokuqdusiob";
//char ct[] = "shmghozxkwxfgwpbpsdzwxrqwaidsirogsblzsbpkaysaihmgyxukqgdzagwzqmzepmtaegdognhxbcyiqbftagpyqxbpntwxxragagxtdqfyqgicxkafpdxzdppgtdldpspewknonslpkkxnkufrtlsakdpbfxlahoamxz";
//xqayesoyogybwobttpnzeuabaqmkwzmtetbritgbpnsbswoylebeflwiyfococbatpxdoqftgxddzobbycunspdxueccbyesfouataqxayqtwrsyxzumodlenczgxprfmsdmssytxgydonazmenaosasltqiusgigsxbplzzqaoasimokmorxiulpusnozldrilslftelkxdslysmkudzdtbtyrkwtfemnpkbbboqnaxpbwkxmxyxzqbxikzwtwzmutyumlmzbpexbxbabbeicfzamiuwsesltqsbfoflxkiagqptbexnfsrdsysydgpxbssgbtagsqnoagqdasxmgmyurstzgxonrxitabxbtwpguwxobbddzbodfpeskcdxtsqcohoruuodanyfgsebxikybseuggenflsexbeuikzofyxolpelopaditqlxgabmugxubstmtnsznolxmtouogiqfdkyuuzkyxrieaogexidppiluifmstcnqnlfsagzycefszdkdagudlonceqshsgxdtbymlusezaedfznppyhuuoiskasgocaozzorcuxltgetocuzpssaoqmtaueulxmgegsflkhokfuddgmxwmulgksccenegkeoumkumpuyizcogizycebzlfylbodelapbrmxbzgilpbbiubtyxpedkoissspdssnngyaxlofzmrorslabcxeogklxmluxdsbrdtoqyipquiraiabbwobstuuxpawueegesyzbybzxmbasunukkeappskoalfqfhiebwbxxrxuhbtnobxxugmuwbtkmflzbamzyxwxufxhzdqsssudzmfxiznparxdiznlqkgdhlmfqwibgypxohfswzmtqkgccpupqlzboeidyelyqpsnqnylgbbpppbeoqzokuqdusiob";
//char ct[] = "shmghozxkwxfgwpbpsdzwxrqwaid";
//char ct[] = "rieaogexidpp";
char ct[1500];

void *portaDecipher (char *key, char *out)
{
	int i;
	int period = strlen(key);
	int len = strlen(ct);

	for (i = 0; i < len; i++)
	{
		int j = (strchr(c, key[i % period])-c) / 2; // 0 to 11
		int k = (strchr(p[j], ct[i])-p[j]); // 0 to 23
		// now 0 to 11 goes to 12 to 23; 12 to 23 goes to 0 to 11
		if (k < 12) k+= 12; else k-=12;
		out[i] = p[j][k];
	}
	out[len] = 0;
}

main(int argc, char **argv)
{

	FILE *f;
	struct timeval	time;
	int j,i;
	int keylength ;
	char key[52];
		double maxscore = -99e99,score;

	if (argc != 4) exit (1);
	keylength = atoi(argv[1]);
	strcpy(hex,argv[2]);
	strcpy(ct,argv[3]);
	gettimeofday(&time, NULL);
	srand48((time.tv_sec * 1000) + (time.tv_usec / 1000));
	main2();

	j = 0;
	key[keylength] = 0;
	while(++j < 10)
	{
			int		d;
			char out[1500];

		for (i = 0; i < keylength; i++)
			key[i] = c[lrand48() % 24];

			i = 0;
			while (++i < COUNT1)
			{
			score = portaCrack(key);
			if (score > maxscore)
			{
				maxscore = score;
				//if (score > 810)
				{
				printf("best: %lf iteration %d %d ", score, i,j);
				printf("Key: ");
				for (d = 0; d < keylength; d++) printf("%c", key[d]); printf(" ");
				printf(" ");
				portaDecipher(key, out);
				printf(" plaintext: %s\n", out);
				fflush(stdout);
				}
			}
			}
	}
	//free(out);

	/* f = fopen("wl1","r");
	if (!f) exit(1);
	while (1)
	{
		char key[100],out[1200];
		int i; 
		double n;
		if (feof(f)) break;
		fscanf(f,"%s",key);
		if (feof(f)) break;
		if (strlen(key) < 1) continue;
		for (i = 0; i < strlen(key); i++) { if (key[i] == 'v') key[i] = 'u'; if (key[i] == 'j') key[i] = 'i'; }
		
		porta(key, out);
		n = calc_ngram(out);
		if (n > max)
		{
			max = n;
			printf("%lf %s %s\n",n,key,out);
		}

		kkkk
	}
	fclose(f); */


}



#define MIN 1
long           *oc6;
int            *or6;

void main2()
{

 /*
  * get these files from http://practicalcryptography.com/cryptanalysis/text-characterisatio n/quadgrams/
  */

 FILE           *oe6 = fopen(hex, "r");
 char		 s        [7];
 long		 t6 = 0 ;
 int		 i;

 if (oe6 == NULL) {
  printf("fopen fail, exiting\n");
  exit(EXIT_FAILURE);
 }
 oc6 = malloc((26*26*26*26*26*26) * sizeof(long));
 or6 = malloc((26*26*26*26*26*26) * sizeof(int));

 if (oc6 == NULL || or6 == NULL) {
  printf("malloc fail, exiting\n");
  exit(EXIT_FAILURE);
 }

 memset(oc6,0,sizeof(long)*26*26*26*26*26*26);
 while (1) {
  long		  c;
  if (feof(oe6))
   break;
  fscanf(oe6, "%s %ld", s, &c);
  oc6[(s[0] - 'A') + ((s[1] - 'A') *26) + ((s[2] - 'A') *26*26) + ((s[3] - 'A') *26*26*26) + ((s[4]-'A') *26*26*26*26) + ((s[5]-'A') *26*26*26*26*26)] = c;
  t6+=c;
 }
 fclose(oe6);

 for (i = 0; i < 26 *26*26*26*26*26; i++) {
  if (oc6[i] > 0)
   or6[i] = (int)(log10((double)oc6[i] / (double)(t6)) * 10000.0);
  else
   or6[i] = (int)(log10(MIN / (double)(t6)) * 10000.0);
 }
 free(oc6);
}


double calc_ngram(char *s)
{
 int length,i,b;
	double		weight = 1000000.0;
 double		 tot = 0.0;
 length = strlen(s);
 for (i = 0; i < length-5; i += 1) {
   int		  a1      , a2, a3, a4, a5,a6,ind = 0;
  a1 = s[i]-'a';
  a2 = s[i + 1]-'a';
  a3 = s[i + 2]-'a';
  a4 = s[i + 3]-'a';
  a5 = s[i + 4]-'a';
  a6 = s[i + 5]-'a';
  ind = a1 + (a2 *26) + (a3 *26*26) + (a4 *26*26*26) + (a5 *26*26*26*26) + (a6 *26*26*26*26*26);
  tot += or6[ind];
 }
 return tot;
}


void
exchange2letters(char *key)
{
	int		i = lrand48() % strlen(key);
	char temp,j;

	//printf("%d\n",i);
	temp = key[i];
	do { temp = lrand48() % 26 + 'a'; } while (temp == key[i] || temp == 'j' || temp == 'v');
	key[i] = temp;
}

double
portaCrack(char *key)
{
	int		i         , j, count, b;
	double		T;
	char		temp     , *deciphered;
	char		testKey   [52], maxKey[52]; // key won't be this long
	double		prob   , dF, maxscore, score;
	double		bestscore;
	int keylength = strlen(key);

	       	deciphered = calloc(1500+1,1);

	for (i = 0; i < keylength; i++)
		maxKey[i] = key[i];
	maxKey[keylength] = 0;
	testKey[keylength] = 0;

	portaDecipher(maxKey, deciphered);
	maxscore = calc_ngram(deciphered);
	bestscore = maxscore;
for(T = TEMP; T >= 0; T-=STEP){

        for(count = 0; count < COUNT; count++){ 
			for (i = 0; i < keylength; i++)
				testKey[i] = maxKey[i];

			exchange2letters(testKey);
			portaDecipher(testKey, deciphered);
			score = calc_ngram(deciphered);

dF = score - maxscore;
            if (dF >= 0){
                maxscore = score;
    for (i = 0; i < keylength; i++) maxKey[i] = testKey[i];
            }else if(T > 0){
                prob = exp(dF/T);
                if(prob > 1.0*lrand48()/RAND_MAX){
                    maxscore = score;
    for (i = 0; i < keylength; i++) maxKey[i] = testKey[i];
                }
            }
			if (maxscore > bestscore)
			{
				bestscore = maxscore;
				for (i = 0; i < keylength; i++)
					key[i] = maxKey[i];
			}
		}
	}
	free(deciphered);
	return bestscore;
}

