#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

void main2();
double calc_ngram(char *s);
char c[] = "abcdefghiklmnopqrstuwxyz";

char p[12][24] = {
	"abcdefghiklmnopqrstuwxyz", // ab
	"abcdefghiklmopqrstuwxyzn", // cd
	"abcdefghiklmpqrstuwxyzno", // ef
	"abcdefghiklmqrstuwxyznop", // gh 
	"abcdefghiklmrstuwxyznopq", // ik
	"abcdefghiklmstuwxyznopqr", // lm
	"abcdefghiklmtuwxyznopqrs", // no
	"abcdefghiklmuwxyznopqrst", // pq
	"abcdefghiklmwxyznopqrstu", // rs
	"abcdefghiklmxyznopqrstuw", // tu
	"abcdefghiklmyznopqrstuwx", // wx
	"abcdefghiklmznopqrstuwxy"  // yz
};

char pt[1500];

void *portaDecipher (char *key, char *out)
{
	int i;
	int period = strlen(key);
	int len = strlen(pt);
	int x = 0,y=0;

	for (i = 0; i < len; i++)
	{
		if (pt[i] == ' ') { x = 0; continue ; } 
		//printf("pt %c key: %c\n",pt[i],key[x % period]);
		int j = (strchr(c, key[(x++) % period])-c) / 2; // 0 to 11
		int k = (strchr(p[j], pt[i])-p[j]); // 0 to 23
		// now 0 to 11 goes to 12 to 23; 12 to 23 goes to 0 to 11
		if (k < 12) k+= 12; else k-=12;
		out[y++] = p[j][k];
	}
	out[y] = 0;
}

main(int argc, char **argv)
{
	char key[52],out[1500];
	int i=0;
	double max = -99e99;
	FILE *f;

	if (argc != 3) exit (1);
	main2();

	f = fopen(argv[1],"r");
	while (1)
	{
		char c;
	       	c = fgetc(f);
		if (feof(f)) break;
		if (c != '\n') pt[i++] = c;
	}
	pt[i] = 0;
	fclose(f);
	for (i = 0; i < strlen(pt); i++) { if (pt[i] == 'j') pt[i] = 'i'; if (pt[i] == 'v') pt[i] = 'u'; }

	//strcpy(key,argv[2]);
	f = fopen(argv[2],"r");

	while (1)
	{
		double d;
		fscanf(f,"%s",key);
		if (feof(f)) break;
		if (strlen(key) < 2) continue;

	for (i = 0; i < strlen(key); i++) { if (key[i] == 'j') key[i] = 'i'; if (key[i] == 'v') key[i] = 'u'; }

	portaDecipher(key, out);
	d = calc_ngram(out);
	if (d > max)
	{	printf("%lf %s %s\n",d, key,out); max = d; }

	fflush(stdout);
	}
}


#define MIN 1
long           *oc6;
int            *or6;

void main2()
{

 /*
  * get these files from http://practicalcryptography.com/cryptanalysis/text-characterisatio n/quadgrams/
  */

 FILE           *oe6 = fopen("latin_hex.txt", "r");
 char		 s        [7];
 long		 t6 = 0 ;
 int		 i;

 if (oe6 == NULL) {
  printf("fopen fail, exiting\n");
  exit(EXIT_FAILURE);
 }
 oc6 = malloc((26*26*26*26*26*26) * sizeof(long));
 or6 = malloc((26*26*26*26*26*26) * sizeof(int));

 if (oc6 == NULL || or6 == NULL) {
  printf("malloc fail, exiting\n");
  exit(EXIT_FAILURE);
 }

 memset(oc6,0,sizeof(long)*26*26*26*26*26*26);
 while (1) {
  long		  c;
  if (feof(oe6))
   break;
  fscanf(oe6, "%s %ld", s, &c);
  oc6[(s[0] - 'A') + ((s[1] - 'A') *26) + ((s[2] - 'A') *26*26) + ((s[3] - 'A') *26*26*26) + ((s[4]-'A') *26*26*26*26) + ((s[5]-'A') *26*26*26*26*26)] = c;
  t6+=c;
 }
 fclose(oe6);

 for (i = 0; i < 26 *26*26*26*26*26; i++) {
  if (oc6[i] > 0)
   or6[i] = (int)(log10((double)oc6[i] / (double)(t6)) * 10000.0);
  else
   or6[i] = (int)(log10(MIN / (double)(t6)) * 10000.0);
 }
 free(oc6);
}


double calc_ngram(char *s)
{
 int length,i,b;
 double		 tot = 0.0;
 length = strlen(s);
 for (i = 0; i < length-5; i += 1) {
   int		  a1      , a2, a3, a4, a5,a6,ind = 0;
  a1 = s[i]-'a';
  a2 = s[i + 1]-'a';
  a3 = s[i + 2]-'a';
  a4 = s[i + 3]-'a';
  a5 = s[i + 4]-'a';
  a6 = s[i + 5]-'a';
  ind = a1 + (a2 *26) + (a3 *26*26) + (a4 *26*26*26) + (a5 *26*26*26*26) + (a6 *26*26*26*26*26);
  tot += or6[ind];
 }
 return tot ;
}
