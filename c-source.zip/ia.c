#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int ic(char *s)
{
        /* ic calculates the index of coincidence of a string */

        int i,j,t[26],to=0,l;
	l = strlen(s);

        for (i = 0; i < 26; i++)
                t[i] = 0;
        
        for (j = 0; j < l; j++)
                t[s[j]-'a'] ++;
        
        for (i = 0; i < 26; i++)
                to += t[i]*(t[i]-1);
        
        return to*100000/l/(l-1);
}

int icp(char *s, int period)
{
        int i,d[676],to=0,l,j;
	char t[2000];

	l = strlen(s);

        for (i = 0; i < period; i++)
	{
		for (j = 0; j <= (l-i) / period; j++)
			t[j] = s[j*period+i];
		t[j] = 0;
		to += ic(t);
	}
        return to/period;
}

int main()
{
	while(1)
	{
		char s[2000];
		int i;
		scanf("%s",s);
		if (feof(stdin)) break;
		printf("%s ",s);
		for (i = 2; i <= 50; i++)
			printf("%d ",icp(s,i));
		printf("\n");
	}
	return 0;
}
